<?php 

namespace app\traits;

/**
 * Hooks handler
 * Define all Hooks callbacks here
 */
trait WP_hooks_handler {

}