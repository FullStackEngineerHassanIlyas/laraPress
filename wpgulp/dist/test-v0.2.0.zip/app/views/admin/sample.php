<h2>sample admin page</h2>
<?php echo do_shortcode( '[short_code]' ); ?>