<?php 

namespace core\interfaces;

interface WP_menu_interface {

	public function menu_pages();
}