<h3>sample shortcode example</h3>
<p><?php echo $sample; ?></p>